<?php
/* CREDENCIAIS DO BANCO DE DADOS */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'SID');
 
/* CONEXAO COM A BASE DA DADOS */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// VERIFICANDO CONEXAO
if($link === false){
    die("ERROR: NAO FOI POSSIVEL SE CONECTAR AO BANCO. " . mysqli_connect_error());
}
?>
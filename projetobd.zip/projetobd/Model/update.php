<?php
// Include config file
require_once "conexao.php";
 
// Define variables and initialize with empty values
$nome = $populacao = $data_criacao = "";
$nome_err = $populacao_err = $data_criacao_err = "";
 
// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate name
    $input_name = trim($_POST["nome"]);
    if(empty($input_name)){
        $nome_err = "Por favor digite um nome";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $nome_err = "Por favor digite um nome válido!";
    } else{
        $nome = $input_name;
    }
    
    // Validate populacao
    $input_populacao = trim($_POST["populacao"]);
    if(empty($input_populacao)){
        $populacao_err = "Por favor digite a quantidade da populacao.";     
    } else{
        $populacao = $input_populacao;
    }
    
    // Validate data_criacao
    $input_data_criacao= trim($_POST["data_criacao"]);
    if(empty($input_data_criacao)){
        $data_criacao_err = "Por favor digite uma data";     
    }else{
        $data_criacao = $input_data_criacao;
    }
    
    // Check input errors before inserting in database
    if(empty($nome_err) && empty($populacao_err) && empty($data_criacao_err)){
        // Prepare an update statement
        $sql = "UPDATE RA SET nome=?, populacao=?, data_criacao=? WHERE codRA=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssi", $param_nome, $param_populacao, $param_data_criacao, $param_id);
            
            // Set parameters
            $param_nome = $nome;
            $param_populacao = $populacao;
            $param_data_criacao = $data_criacao;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: ../index.php");
                exit();
            } else{
                echo "Houve um problema, tente novamente mais tarde";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM RA WHERE codRA = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $nome= $row["nome"];
                    $populacao = $row["populacao"];
                    $data_criacao = $row["data_criacao"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.html");
                    exit();
                }
                
            } else{
                echo "Oops! Houve um problema, tente novamente mais tarde";
            }
        }
        
        // Close statement
        //mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($link);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.html");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Atualizar Regiao Administrativa</h2>
                    </div>
                    <p>Please edit the input values and submit to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nome_err)) ? 'has-error' : ''; ?>">
                            <label>Nome da Regiao Administrativa</label>
                            <input type="text" name="nome" class="form-control" value="<?php echo $nome; ?>">
                            <span class="help-block"><?php echo $nome_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($populacao_err)) ? 'has-error' : ''; ?>">
                            <label>Populacao</label>
                            <input type="text" name="populacao" class="form-control" value="<?php echo $populacao; ?>">
                            <span class="help-block"><?php echo $populacao_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($data_criacao_err)) ? 'has-error' : ''; ?>">
                            <label>Data de Criacao da RA</label>
                            <input type="date" name="data_criacao" class="form-control" value="<?php echo $data_criacao; ?>">
                            <span class="help-block"><?php echo $data_criacao_err;?></span>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Atualizar">
                        <a href="../index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
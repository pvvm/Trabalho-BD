<?php
// Check existence of id parameter before processing further
if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    // Include config file
    require_once "conexao.php";
    
    // Prepare a select statement
    $sql = "SELECT * FROM RA WHERE codRA = ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
                // Retrieve individual field value
                $nome = $row["nome"];
                $populacao = $row["populacao"];
                $data_criacao = $row["data_criacao"];
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.html");
                exit();
            }
            
        } else{
            echo "Oops! Alguma coisa deu errado, tente novamente mais tarde!";
        }
    }
     
} else{
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper" style="left:25%;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h1>Visualizar Regiao Administrativa</h1>
                    </div>
                    <div class="form-group">
                        <label>Nome da Regiao Administrativa</label>
                        <p class="form-control-static"><?php echo $row["nome"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>Populacao Registrada</label>
                        <p class="form-control-static"><?php echo $row["populacao"]; ?></p>
                    </div>
                    <div class="form-group">
                        <label>Data da criacao da RA</label>
                        <p class="form-control-static"><?php $data = new DateTime($row['data_criacao']);
                                        echo "<td>" . $data->format('d/m/Y'). "</td>";?></p>
                    </div>
                </div>
            </div>     
        </div>
    </div>


    <div style="position: absolute;left:25%;margin-right: -50%;">
        <div class="col-md-12" align="center">
                    <div class="page-header">
                        <h3>Alagamentos Registrados nesta área</h3>
                    </div>
                    <div class="container-fluid">
                    <?php
                    // Include config file
                    require_once "conexao.php";
                    $param_id = trim($_GET["id"]);
                    // Attempt select query execution
                    $sql = "SELECT RA.nome as nomeregiao, B.nome as nomebairro, B.codBairro, A.codAlagamento, A.dia, A.rua, A.inicio, A.fim, A.imagem  
                            FROM RA 
                            INNER JOIN BAIRRO B ON B.codRA = RA.codRA 
                            INNER JOIN Alagamento A ON A.codBairro = B.codBairro 
                            WHERE RA.codRA = {$param_id}";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo "<table class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>Imagem</th>";
                                        echo "<th>Regiao Administrativa</th>";
                                        echo "<th>Bairro</th>";
                                        echo "<th>Rua</th>";
                                        echo "<th>Dia</th>";
                                        echo "<th>Inicio</th>";
                                        echo "<th>Fim</th>";
                                        echo "<th>AcoesES</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['imagem'] . "</td>";
                                        echo "<td>" . $row['nomeregiao'] . "</td>";
                                        echo "<td>" . $row['nomebairro'] . "</td>";
                                        echo "<td>" . $row['rua'] . "</td>";
                                        $data = new DateTime($row['dia']);
                                        echo "<td>" . $data->format('d/m/Y'). "</td>";
                                        echo "<td>" . $row['inicio'] . "</td>";
                                        echo "<td>" . $row['fim'] . "</td>";
                                        echo "<td><a href='alagamento/deletealagamento.php?codAlag=".$row['codAlagamento']."&codBairro=".$row['codBairro']."' title='Apagar Alagamento' data-toggle='tooltip' class='btn btn-danger btn-circle'><i class='fas fa-trash'>Excluir</i></a></td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{

                            echo "<p class='lead'><em>Nenhum alagamento registrado para esta Regiao Administrativa</em></p>";
                        }
                    } else{
                        echo "ERROR: Nao foi possivel executar a consulta. " . mysqli_error($link);
                    }
                    
                    // Close connection
                    mysqli_close($link);
                    ?>


                </div>
                <p>
                    <?php
                        echo "<a href='alagamento/createalagamento.php?id=". $param_id ."' title='Cadastrar' data-toggle='tooltip' class='btn btn-success btn-circle'>Cadastrar<i class='fas fa-check'></i></a>     ";
                    ?> <a href="../index.php" class="btn btn-primary">Voltar</a></p></div>
                    
          </div>

      </div>

</body>
</html>
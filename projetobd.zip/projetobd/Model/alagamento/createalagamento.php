<?php
// Include config file
require_once "../conexao.php";
 
$codRA = trim($_GET["id"]);
// Define variables and initialize with empty values
$dia= $rua= $inicio= $fim= $bairro= "";
$dia_err = $rua_err = $inicio_err = $fim_err = $bairro_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){


    // Validate populacao
    $input_rua = trim($_POST["rua"]);
    if(empty($input_rua)){
        $rua_err = "Por favor digite a Rua";     
    } else{
        $rua = $input_rua;
    }

    // Validate populacao
    $input_bairro = trim($_POST["bairro"]);
    if(empty($input_bairro)){
        $bairro_err = "Por favor digite o Bairro";     
    } else{
        $bairro = $input_bairro;
    }

    // Validate populacao
    $input_dia = trim($_POST["dia"]);
    if(empty($input_dia)){
        $dia_err = "Por favor digite o Dia";     
    } else{
        $dia = $input_dia;
    }

    // Validate populacao
    $input_inicio = trim($_POST["inicio"]);
    if(empty($input_inicio)){
        $rua_err = "Por favor digite o Inicio";     
    } else{
        $inicio = $input_inicio;
    }

    // Validate populacao
    $input_fim= trim($_POST["fim"]);
    if(empty($input_rua)){
        $fim_err = "Por favor digite o Fim";     
    } else{
        $fim = $input_fim;
    }

    if(empty($bairro_err)){

        // Prepare an insert statement
        $sql = "INSERT INTO Bairro(codRA, nome) VALUES ({$codRA},?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
           
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_bairro);
        
            $param_bairro = $bairro;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){

               // Check input errors before inserting in database
                    if(empty($rua_err) && empty($dia_err) && empty($inicio_err) && empty($fim_err)){

                        $consultaUltimoCodigoBairro = $link->query("SELECT MAX(codBairro) as codBairro FROM Bairro");
                        $result = $consultaUltimoCodigoBairro->fetch_array(MYSQLI_NUM);
                        $codigoBairro = intval($result['0']);

                        // Prepare an insert statement
                        $sql = "INSERT INTO Alagamento (codBairro, dia, rua, inicio, fim) VALUES ({$codigoBairro},?, ?, ?, ?)";
                         
                        if($stmt = mysqli_prepare($link, $sql)){
                           
                            // Bind variables to the prepared statement as parameters
                            mysqli_stmt_bind_param($stmt, "ssss", $param_dia, $param_rua, $param_inicio, $param_fim);
                        
                            // Set parameters
                            $stamp = strtotime(str_replace("/","-",$dia));
                            $param_dia= date('Y-m-d',$stamp);
                            $param_rua = $rua;
                            $param_inicio = $inicio;
                            $param_fim = $fim;

                            // Attempt to execute the prepared statement
                            if(mysqli_stmt_execute($stmt)){
                                // Records created successfully. Redirect to landing page
                                header("location: ../visualizar.php?id=".$codRA);
                                exit();
                            } else{
                                echo "Algo deu errado, tente novamente mais tarde...";
                            }
                        }
                         
                        // Close statement
                        //mysqli_stmt_close($stmt);
                    }
            } else{
                echo "Algo deu errado, tente novamente mais tarde...";
            }
        }

    }
    
    
    
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Registro de novo Alagamento</h2>
                    </div>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'?id='.$codRA); ?>" method="post">
                        <div class="form-group <?php echo (!empty($rua_err)) ? 'has-error' : ''; ?>">
                            <label>Digite o Endereco do alagamento</label>
                            <input type="text" name="rua" class="form-control" value="<?php echo $rua; ?>">
                            <span class="help-block"><?php echo $rua_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($bairro_err)) ? 'has-error' : ''; ?>">
                            <label>Digite o Bairro do alagamento</label>
                            <input type="text" name="bairro" class="form-control" value="<?php echo $bairro; ?>">
                            <span class="help-block"><?php echo $bairro_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($dia_err)) ? 'has-error' : ''; ?>">
                            <label>Data do Alagamento</label>
                            <input type="text" name="dia" class="form-control" value= "<?php echo $dia; ?>">
                            <span class="help-block"><?php echo $dia_err;?></span>
                        </div>
                         <div class="form-group <?php echo (!empty($inicio_err)) ? 'has-error' : ''; ?>">
                            <label>Hora Inicial</label>
                            <input type="text" name="inicio" class="form-control" value= "<?php echo $inicio; ?>">
                            <span class="help-block"><?php echo $inicio_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fim_err)) ? 'has-error' : ''; ?>">
                            <label>Hora Final</label>
                            <input type="text" name="fim" class="form-control" value="<?php echo $fim; ?>">
                            <span class="help-block"><?php echo $fim_err;?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Salvar">
                        <a href="../visualizar.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
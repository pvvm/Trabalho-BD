<?php
// Include config file
require_once "conexao.php";
 
// Define variables and initialize with empty values
$nome = $populacao = $data_criacao = "";
$nome_err = $populacao_err = $data_criacao_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_nome = trim($_POST["nome"]);
    if(empty($input_nome)){
        $nome_err = "Por favor digite um nome da RA";
    } elseif(!filter_var($input_nome, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $nome_err = "Por favor digite um nome valido!";
    } else{
        $nome = $input_nome;
    }
    
    // Validate populacao
    $input_populacao = trim($_POST["populacao"]);
    if(empty($input_populacao)){
        $populacao_err = "Por favor digite a quantidade da populacao.";     
    } else{
        $populacao = $input_populacao;
    }
    
    // Validate data_criacao
    $input_data_criacao= trim($_POST["data_criacao"]);
    if(empty($input_data_criacao)){
        $data_criacao_err = "Por favor digite uma data";     
    }else{
        $data_criacao = $input_data_criacao;
    }
    
    // Check input errors before inserting in database
    if(empty($nome_err) && empty($populacao_err) && empty($data_criacao_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO RA (nome, populacao, data_criacao) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $param_nome, $param_populacao, $param_data_criacao);
            
            // Set parameters
            $param_nome = $nome;
            $param_populacao = $populacao;

            $stamp = strtotime(str_replace("/","-",$data_criacao));
            $param_data_criacao= date('Y-m-d',$stamp);

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: ../index.php");
                exit();
            } else{
                echo "Algo deu errado, tente novamente mais tarde...";
            }
        }
         
        // Close statement
        //mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Criando uma Regiao Administrativa</h2>
                    </div>
                    <p>Please fill this form and submit to add employee record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($nome_err)) ? 'has-error' : ''; ?>">
                            <label>Nome da Regiao Administrativa</label>
                            <input type="text" name="nome" class="form-control" value="<?php echo $nome; ?>">
                            <span class="help-block"><?php echo $nome_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($populacao_err)) ? 'has-error' : ''; ?>">
                            <label>Populacao</label>
                            <input type="text" name="populacao" class="form-control" value= "<?php echo $populacao; ?>">
                            <span class="help-block"><?php echo $populacao_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($data_criacao_err)) ? 'has-error' : ''; ?>">
                            <label>Data de Criacao da RA</label>
                            <input type="date" name="data_criacao" class="form-control" value="<?php echo $data_criacao; ?>">
                            <span class="help-block"><?php echo $data_criacao_err;?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Salvar">
                        <a href="../index.php" class="btn btn-default">Cancelar</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>